require("addon")

math.randomseed(os.time())

local state = rawget(_G, "__br_state")
if not state then
	state = {}
	_G.__br_state = state
end

state.cycle = state.cycle or 0
state.auth_sent = state.auth_sent or false
state.auth_flow_active = state.auth_flow_active or false
state.auth_t0_seen = state.auth_t0_seen or false
state.auth_t9_sent = state.auth_t9_sent or false
state.auth_c1_sent = state.auth_c1_sent or false
state.auth_gui50_t1_sent = state.auth_gui50_t1_sent or false
state.auth_ui_ready_seen = state.auth_ui_ready_seen or false
state.promo_started = state.promo_started or false
state.promo_completed = state.promo_completed or false
state.promo_command_sent = state.promo_command_sent or false
state.promo_cycle_id = state.promo_cycle_id or 0
state.promo_stage = state.promo_stage or 0
state.register_sent = state.register_sent or false
state.registration_scenario_active = state.registration_scenario_active or false
state.registration_t0_count = state.registration_t0_count or 0
state.registration_cycle_id = state.registration_cycle_id or 0
state.registration_stage = state.registration_stage or 0
state.nick = state.nick or nil
state.server = state.server or nil
state.password = state.password or nil

local CREDENTIALS_FILE = "autoacc_credentials.txt"
local T9_DEVICE_ID = "fN0UUN65TmOw-E_ypVY5Zc"
local T9_APPMETRICA_DEVICE_ID = "14002942597165712377"
local T9_ADJUST_ID = "777069ce6e7e3974d37c9bba06cd7658"
local PROMO_CODE = "#create"

local function trim(s)
	if not s then
		return nil
	end
	return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function read_all(path)
	local f = io.open(path, "r")
	if not f then
		return nil
	end
	local data = f:read("*a")
	f:close()
	return data
end

local function load_ini_settings()
	local ini = read_all("settings\\RakSAMP Lite.ini")
	if not ini then
		return nil, nil, nil
	end

	local ip = ini:match("[\r\n][Ii][Pp]%s*=%s*([^\r\n]+)") or ini:match("^%s*[Ii][Pp]%s*=%s*([^\r\n]+)")
	local nick = ini:match("[\r\n][Nn][Ii][Cc][Kk]%s*=%s*([^\r\n]+)") or ini:match("^%s*[Nn][Ii][Cc][Kk]%s*=%s*([^\r\n]+)")
	local pass = ini:match("[\r\n][Pp][Aa][Ss][Ss]%s*=%s*([^\r\n]*)") or ini:match("^%s*[Pp][Aa][Ss][Ss]%s*=%s*([^\r\n]*)")

	return trim(nick), trim(ip), trim(pass)
end

local function load_xml_settings()
	local xml = read_all("RakSAMPClient.xml") or read_all("RakSAMP Lite.xml")
	if not xml then
		return nil, nil, nil
	end

	local nickname = xml:match('<server%s+nickname="([^"]*)"')
	local password = xml:match('<server%s+nickname="[^"]*"%s+password="([^"]*)"')
	local server = xml:match("<server[^>]*>([^<]+)</server>")

	return trim(nickname), trim(server), trim(password)
end

local function ensure_profile()
	local runtime_nick = getCurrentNickname and getCurrentNickname() or nil
	local runtime_server = getCurrentServer and getCurrentServer() or nil
	local runtime_pass = getCurrentPassword and getCurrentPassword() or nil

	if runtime_nick and runtime_nick ~= "" then
		state.nick = trim(runtime_nick)
	end
	if runtime_server and runtime_server ~= "" then
		state.server = trim(runtime_server)
	end
	if runtime_pass and runtime_pass ~= "" then
		state.password = trim(runtime_pass)
	end

	if state.nick and state.server then
		return
	end

	local nick, server, pass = load_ini_settings()
	if not nick or not server then
		nick, server, pass = load_xml_settings()
	end

	if nick and nick ~= "" then
		state.nick = nick
	end
	if server and server ~= "" then
		state.server = server
	end
	if pass and pass ~= "" then
		state.password = pass
	end
end

local function make_password()
	local alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	local out = {}
	for i = 1, 12 do
		local idx = math.random(1, #alphabet)
		out[i] = alphabet:sub(idx, idx)
	end
	return table.concat(out)
end

local function load_saved_password()
	ensure_profile()
	if not state.nick or not state.server then
		return nil
	end

	local data = read_all(CREDENTIALS_FILE)
	if not data then
		return nil
	end

	local last_pass = nil
	for line in data:gmatch("[^\r\n]+") do
		local line_nick = trim(line:match("nick=([^|]+)"))
		local line_pass = trim(line:match("pass=([^|]+)"))
		local line_server = trim(line:match("server=([^|]+)"))
		if line_nick and line_pass and line_server then
			if line_nick:lower() == state.nick:lower() and line_server:lower() == state.server:lower() then
				last_pass = line_pass
			end
		end
	end

	return last_pass
end

local function save_password(pass)
	ensure_profile()
	if not state.nick or not state.server or not pass or pass == "" then
		return
	end

	local existing = load_saved_password()
	if existing and existing == pass then
		return
	end

	local f = io.open(CREDENTIALS_FILE, "a")
	if not f then
		print("[AUTOAUTH] failed to open credentials file")
		return
	end

	f:write(string.format("%s | nick=%s | pass=%s | server=%s\n", os.date("%Y-%m-%d %H:%M:%S"), state.nick, pass, state.server))
	f:close()
	print(string.format("[AUTOAUTH] saved credentials for %s @ %s", state.nick, state.server))
end

local function ensure_password_for_auth()
	if state.password and state.password ~= "" then
		return state.password
	end

	local saved = load_saved_password()
	if saved and saved ~= "" then
		state.password = saved
		return saved
	end

	return nil
end

local function ensure_password_for_registration()
	local pass = ensure_password_for_auth()
	if pass and pass ~= "" then
		return pass
	end

	pass = make_password()
	state.password = pass
	save_password(pass)
	return pass
end

local function send_gui_json(guiid, fragment)
	runCommand(string.format("!sendjson %d %s", guiid, fragment))
end

local function send_t9_payload()
	send_gui_json(38, string.format(
		'{"t":9,"id":"%s","appmetrica_device_id":"%s","adjust_id":"%s"}',
		T9_DEVICE_ID,
		T9_APPMETRICA_DEVICE_ID,
		T9_ADJUST_ID
	))
end

local function reset_cycle()
	ensure_profile()
	state.cycle = state.cycle + 1
	state.auth_sent = false
	state.auth_flow_active = false
	state.auth_t0_seen = false
	state.auth_t9_sent = false
	state.auth_c1_sent = false
	state.auth_gui50_t1_sent = false
	state.auth_ui_ready_seen = false
	state.promo_started = false
	state.promo_completed = false
	state.promo_command_sent = false
	state.promo_stage = 0
	state.register_sent = false
	state.registration_scenario_active = false
	state.registration_t0_count = 0
	state.registration_stage = 0
	state.registration_cycle_id = state.registration_cycle_id + 1
	state.promo_cycle_id = state.registration_cycle_id
end

local function send_auth_if_needed()
	if state.auth_sent then
		return
	end

	local pass = ensure_password_for_auth()
	if not pass or pass == "" then
		print("[AUTOAUTH] no saved password for this nick/server")
		return
	end

	state.auth_flow_active = true
	state.auth_t0_seen = false
	state.auth_t9_sent = false
	state.auth_c1_sent = false
	state.auth_gui50_t1_sent = false
	newTask(function()
		wait(150)
		if not state.auth_flow_active then
			return
		end
		send_t9_payload()
		state.auth_t9_sent = true
		print("[AUTOAUTH] auth preflight t:9 sent")

		wait(3840)
		if not state.auth_flow_active then
			return
		end
		ensure_profile()
		if not state.password or state.password == "" then
			return
		end
		send_gui_json(38, string.format('{"t":6,"s":"%s","r":0}', pass))
		state.auth_sent = true
		print("[AUTOAUTH] auth payload sent")
	end)
end

local function start_registration_scenario()
	if state.registration_scenario_active then
		return
	end

	local pass = ensure_password_for_registration()
	state.registration_scenario_active = true
	state.register_sent = true
	state.registration_t0_count = 0
	state.registration_stage = 1

	local cycle_id = state.registration_cycle_id

	newTask(function()
		wait(1150)
		if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active then
			return
		end
		send_t9_payload()
		print("[AUTOAUTH] registration stage t:9 sent")

		wait(7100)
		if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active then
			return
		end
		ensure_profile()
		send_gui_json(38, string.format('{"t":1,"s":"","p":"%s"}', pass))
		state.registration_stage = 2
		print("[AUTOAUTH] registration stage t:1 sent")
	end)
end

local function schedule_auth_c1(reason, delay_ms)
	if state.auth_c1_sent then
		return
	end

	state.auth_c1_sent = true
	newTask(function()
		wait(delay_ms or 8)
		if not state.auth_flow_active then
			return
		end
		send_gui_json(38, '{"c":1}')
		print(string.format("[AUTOAUTH] auth flow c:1 sent (%s)", reason))
	end)
end

local function contains_any(haystack, variants)
	if not haystack or haystack == "" then
		return false
	end
	for _, variant in ipairs(variants) do
		if haystack:find(variant, 1, true) ~= nil then
			return true
		end
	end
	return false
end

local function schedule_promo_after_spawn(reason, delay_ms)
	if state.promo_started or state.promo_command_sent then
		return
	end

	state.promo_completed = false
	state.promo_command_sent = true
	state.promo_stage = 0
	local cycle_id = state.promo_cycle_id
	newTask(function()
		wait(delay_ms or 2500)
		if cycle_id ~= state.promo_cycle_id or state.promo_completed then
			return
		end
		sendInput("/promo")
		state.promo_started = true
		state.promo_stage = 1
		print(string.format("[AUTOAUTH] promo command sent (%s)", reason))
	end)
end

registerHandler("onSendSpawn", function()
	schedule_promo_after_spawn("spawn-rpc", 3200)
end)

registerHandler("onShowDialog", function(dialogId, style, title, button1, button2, text)
	local isPromoMenu = is_promo_menu_dialog_v2(style, text)
	local isPromoInput = is_promo_input_dialog_v2(style, text)
	local isPromoSuccess = is_promo_success_dialog_v2(text)

	if not isPromoMenu and not isPromoInput and not isPromoSuccess then
		return
	end

	print(string.format(
		"[AUTOAUTH2] promo dialog inspect style=%s menu=%s input=%s success=%s stage=%s completed=%s",
		tostring(style),
		tostring(isPromoMenu),
		tostring(isPromoInput),
		tostring(isPromoSuccess),
		tostring(state.promo_stage),
		tostring(state.promo_completed)
	))

	if isPromoMenu then
		local firstLine = get_first_dialog_line(text)
		if firstLine and firstLine ~= "" then
			state.promo_started = true
			state.promo_completed = false
			state.promo_stage = 2
			sendDialogResponse(dialogId, 1, 0, firstLine)
			print(string.format("[AUTOAUTH2] promo menu selection sent (dialog=%s text=%s)", tostring(dialogId), firstLine))
		else
			print("[AUTOAUTH2] promo menu detected but first line is empty")
		end
		return
	end

	if isPromoInput then
		state.promo_started = true
		state.promo_completed = false
		state.promo_stage = 3
		sendDialogResponse(dialogId, 1, 0, PROMO_CODE)
		print(string.format("[AUTOAUTH2] promo code entered (dialog=%s code=%s)", tostring(dialogId), PROMO_CODE))
		return
	end

	if isPromoSuccess then
		state.promo_started = true
		state.promo_completed = true
		state.promo_stage = 4
		sendDialogResponse(dialogId, 1, 0, "")
		print("[AUTOAUTH2] promo activation completed")
	end
end)

local function log_dialog(dialogId, style, title, button1, button2, text)
	print("[DIALOG] ===============================")
	print(string.format("[DIALOG] id=%s style=%s", tostring(dialogId), tostring(style)))
	print(string.format("[DIALOG] title=%s", tostring(title or "")))
	if (button1 and button1 ~= "") or (button2 and button2 ~= "") then
		print(string.format("[DIALOG] buttons=[%s] [%s]", tostring(button1 or ""), tostring(button2 or "")))
	end

	local body = tostring(text or "")
	local line_index = 1
	for line in body:gmatch("[^\r\n]+") do
		print(string.format("[DIALOG] %d. %s", line_index, line))
		line_index = line_index + 1
	end
end

local function lower_text(value)
	return tostring(value or ""):lower()
end

local function json_escape(value)
	value = tostring(value or "")
	value = value:gsub("\\", "\\\\")
	value = value:gsub("\"", "\\\"")
	return value
end

local function get_first_dialog_line(text)
	local bodyText = tostring(text or "")
	for line in bodyText:gmatch("[^\r\n]+") do
		local trimmed = trim(line)
		if trimmed and trimmed ~= "" then
			return trimmed
		end
	end
	return nil
end

local function is_promo_menu_dialog(style, title, text)
	local titleText = lower_text(title)
	local bodyText = lower_text(text)
	return style == 4 and (
		contains_any(titleText, {"промокод", "рџсђрѕрјрѕрєрѕрґ"}) or
		(bodyText:find("#1", 1, true) ~= nil and bodyText:find("актив", 1, true) ~= nil)
	)
end

local function is_promo_input_dialog(style, title, text)
	local titleText = lower_text(title)
	local bodyText = lower_text(text)
	return style == 1 and (
		contains_any(titleText, {"промокод", "рџсђрѕрјрѕрєрѕрґ"}) or
		contains_any(bodyText, {"введите промокод", "р’рірµрґрёс‚рµ рїсђрѕрјрѕрєрѕрґ"})
	)
end

local function is_promo_success_dialog(title, text)
	local titleText = lower_text(title)
	local bodyText = lower_text(text)
	return
		contains_any(titleText, {"активация промокода", "рђрєс‚рёрір°с†рёсџ рїсђрѕрјрѕрєрѕрґр°"}) or
		contains_any(bodyText, {"поздравляем", "рџрѕр·рґсђр°рір»сџрµрј"}) or
		contains_any(bodyText, {"успешно активировали промокод", "р°рєс‚рёрірёрђрѕрір°р»рё рїсђрѕрјрѕрєрѕрґ"})
end

local function is_promo_menu_dialog_v2(style, text)
	local bodyText = lower_text(text)
	return style == 4 and bodyText:find("#1", 1, true) ~= nil
end

local function is_promo_input_dialog_v2(style, text)
	local bodyText = lower_text(text)
	return style == 1 and (
		bodyText:find("введите промокод", 1, true) ~= nil or
		bodyText:find("1.", 1, true) ~= nil
	)
end

local function is_promo_success_dialog_v2(text)
	local bodyText = lower_text(text)
	return
		bodyText:find(PROMO_CODE:lower(), 1, true) ~= nil or
		bodyText:find("поздравляем", 1, true) ~= nil or
		bodyText:find("успешно активировали промокод", 1, true) ~= nil
end

registerHandler("onGui", function(guiid, json)
	if type(json) ~= "string" then
		return
	end

	if guiid == 50 and state.auth_flow_active then
		local has_menu = json:find('"m"%s*:') ~= nil
		if has_menu and not state.auth_c1_sent then
			schedule_auth_c1("gui50", 8)

			newTask(function()
				wait(850)
				if not state.auth_flow_active or state.auth_gui50_t1_sent then
					return
				end
				send_gui_json(50, '{"t":1}')
				state.auth_gui50_t1_sent = true
				print("[AUTOAUTH] auth flow gui50 t:1 sent")
			end)
		end
	end

	if (guiid == 100 or guiid == 111) and state.auth_flow_active and state.auth_t0_seen then
		state.auth_ui_ready_seen = true
		if not state.auth_c1_sent then
			schedule_auth_c1(guiid == 100 and "gui100-fallback" or "gui111-fallback", 25)
		end
	end

	if guiid == 39 or guiid == 65 or guiid == 76 then
		if guiid == 76 then
			schedule_promo_after_spawn("gui76", 1800)
		elseif guiid == 65 or guiid == 39 then
			schedule_promo_after_spawn(guiid == 65 and "gui65" or "gui39", 3200)
		end

		state.auth_flow_active = false
		state.auth_t0_seen = false
		state.auth_t9_sent = false
		state.auth_c1_sent = false
		state.auth_gui50_t1_sent = false
		state.auth_ui_ready_seen = false
	end

	if guiid ~= 38 then
		return
	end

	ensure_profile()

	local o = json:match('"o"%s*:%s*(-?%d+)')
	local r = json:match('"r"%s*:%s*(-?%d+)')
	local t = json:match('"t"%s*:%s*(-?%d+)')
	local has_lk = json:find('"lk"%s*:') ~= nil

	if has_lk then
		reset_cycle()
	end

	if o == "1" and r == "1" then
		send_auth_if_needed()
		return
	end

	if o == "1" and r == "0" then
		start_registration_scenario()
		return
	end

	if t == "0" then
		if state.auth_flow_active and not state.registration_scenario_active and not state.auth_t0_seen then
			state.auth_t0_seen = true
			send_t9_payload()
			print("[AUTOAUTH] auth post-login t:9 sent")
		end

		if state.registration_scenario_active then
			state.registration_t0_count = state.registration_t0_count + 1
			if state.registration_stage == 2 then
				send_gui_json(38, '{"t":2,"s":"","r":0}')
				print("[AUTOAUTH] registration stage t:2 sent")
				state.registration_stage = 3
			end

			send_t9_payload()
			print("[AUTOAUTH] registration stage t:9 resent on t:0")

			if state.registration_stage == 3 then
				state.registration_stage = 4
				local cycle_id = state.registration_cycle_id
				newTask(function()
					wait(1150)
					if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active or state.registration_stage ~= 4 then
						return
					end
					send_gui_json(38, '{"t":4,"s":""}')
					state.registration_stage = 5
					print("[AUTOAUTH] registration stage t:4 sent")
				end)
			elseif state.registration_stage == 5 then
				state.registration_stage = 6
				local cycle_id = state.registration_cycle_id
				newTask(function()
					wait(780)
					if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active or state.registration_stage ~= 6 then
						return
					end
					send_gui_json(38, '{"t":3,"r":0}')
					print("[AUTOAUTH] registration stage t:3 sent")

					wait(170)
					if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active or state.registration_stage ~= 6 then
						return
					end
					send_gui_json(38, '{"t":5,"r":78}')
					state.registration_stage = 7
					print("[AUTOAUTH] registration stage t:78 sent")
				end)
			elseif state.registration_stage == 7 then
				state.registration_stage = 8
				local cycle_id = state.registration_cycle_id
				newTask(function()
					wait(800)
					if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active or state.registration_stage ~= 8 then
						return
					end
					send_gui_json(38, '{"t":5,"r":78}')
					print("[AUTOAUTH] registration stage t:5 sent")

					wait(20)
					if cycle_id ~= state.registration_cycle_id or not state.registration_scenario_active or state.registration_stage ~= 8 then
						return
					end
					send_gui_json(38, '{"c":1}')
					state.registration_stage = 9
					state.registration_scenario_active = false
					print("[AUTOAUTH] registration scenario completed")
				end)
			end
		end
		return
	end
end)

registerHandler("onShowDialog", function(dialogId, style, title, button1, button2, text)
	log_dialog(dialogId, style, title, button1, button2, text)

	if state.promo_completed then
		print("[AUTOAUTH] promo dialog skipped because promo_completed=true")
		return
	end

	local isPromoMenu = is_promo_menu_dialog_v2(style, text)
	local isPromoInput = is_promo_input_dialog_v2(style, text)
	local isPromoSuccess = is_promo_success_dialog_v2(text)

	print(string.format(
		"[AUTOAUTH] promo dialog inspect style=%s menu=%s input=%s success=%s stage=%s",
		tostring(style),
		tostring(isPromoMenu),
		tostring(isPromoInput),
		tostring(isPromoSuccess),
		tostring(state.promo_stage)
	))

	if isPromoSuccess then
		state.promo_started = true
		sendDialogResponse(dialogId, 1, 0, "")
		state.promo_completed = true
		state.promo_stage = 3
		print("[AUTOAUTH] promo activation completed")
		return
	end

	if isPromoMenu then
		state.promo_started = true
		local firstLine = get_first_dialog_line(text)
		if firstLine and firstLine ~= "" then
			sendDialogResponse(dialogId, 1, 0, firstLine)
			state.promo_stage = 2
			print(string.format("[AUTOAUTH] promo menu selection sent (dialog=%s text=%s)", tostring(dialogId), firstLine))
		end
		return
	end

	if isPromoInput then
		state.promo_started = true
		sendDialogResponse(dialogId, 1, 0, PROMO_CODE)
		state.promo_stage = 3
		print(string.format("[AUTOAUTH] promo code entered (dialog=%s code=%s)", tostring(dialogId), PROMO_CODE))
		return
	end

	local titleText = title or ""
	local bodyText = text or ""
	local isPromoRoot =
		contains_any(titleText, {"Промокод", "промокод"}) or
		contains_any(bodyText, {"Введите промокод", "введите промокод"}) or
		contains_any(bodyText, {"Активация промокода", "активация промокода"})
	local isPromoSuccess =
		contains_any(titleText, {"Активация промокода", "активация промокода"}) or
		contains_any(bodyText, {"Поздравляем", "поздравляем"}) or
		contains_any(bodyText, {"активировал промокод", "Активировал промокод"})

	if not state.promo_started and not isPromoRoot and not isPromoSuccess then
		return
	end

	if isPromoSuccess then
		send_gui_json(10, '{"r":1,"i":"","l":-1}')
		state.promo_completed = true
		print("[AUTOAUTH] promo activation completed")
		return
	end

	if isPromoRoot then
		send_gui_json(10, string.format('{"r":1,"i":"%s","l":-1}', PROMO_CODE))
		print(string.format("[AUTOAUTH] promo dialog response sent (dialog=%s code=%s)", tostring(dialogId), PROMO_CODE))
	end
end)
