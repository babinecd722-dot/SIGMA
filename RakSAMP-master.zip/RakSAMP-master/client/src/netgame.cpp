/*
	Updated to 0.3.7 by P3ti
*/

#include "main.h"

extern int iFollowingPassenger, iFollowingDriver;
extern int iDrunkLevel, iMoney, iLocalPlayerSkin;
extern BYTE m_bLagCompensation;

DWORD dwTimeReconnect = 10000;

int iPassengerNotificationSent = 0, iDriverNotificationSent = 0;
static bool g_authKeyHandled = false;
static bool g_gui111SpawnPending = false;
static DWORD g_gui111LastPacketTick = 0;
static DWORD g_spawnClassRetryTick = 0;
static DWORD g_spawnWaitLogTick = 0;
static DWORD g_gui50LastAutoReplyTick = 0;
static DWORD g_pkt9WindowTick = 0;
static int g_pkt9WindowCount = 0;
static int g_pkt9LastLen = 0;
static int g_pkt9LastTs = 0;

static bool IsAuthTokenChar(char c)
{
    return (c >= '0' && c <= '9') ||
        (c >= 'A' && c <= 'Z') ||
        (c >= 'a' && c <= 'z');
}

static bool Cp1251ToUtf8Local(const char* src, char* dst, int dstSize)
{
	if (src == 0 || dst == 0 || dstSize <= 0)
		return false;
	dst[0] = '\0';

	int wlen = MultiByteToWideChar(1251, 0, src, -1, 0, 0);
	if (wlen <= 0) return false;
	WCHAR* wbuf = new WCHAR[wlen];
	if (!wbuf) return false;
	if (MultiByteToWideChar(1251, 0, src, -1, wbuf, wlen) <= 0)
	{
		delete[] wbuf;
		return false;
	}
	int ulen = WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, 0, 0, 0, 0);
	if (ulen <= 0)
	{
		delete[] wbuf;
		return false;
	}
	char* ubuf = new char[ulen];
	if (!ubuf)
	{
		delete[] wbuf;
		return false;
	}
	if (WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, ubuf, ulen, 0, 0) <= 0)
	{
		delete[] ubuf;
		delete[] wbuf;
		return false;
	}
	strncpy_s(dst, dstSize, ubuf, _TRUNCATE);
	delete[] ubuf;
	delete[] wbuf;
	return true;
}

static bool Utf8ToCp1251Local(const char* src, char* dst, int dstSize)
{
	if (src == 0 || dst == 0 || dstSize <= 0)
		return false;
	dst[0] = '\0';

	int wlen = MultiByteToWideChar(CP_UTF8, 0, src, -1, 0, 0);
	if (wlen <= 0) return false;
	WCHAR* wbuf = new WCHAR[wlen];
	if (!wbuf) return false;
	if (MultiByteToWideChar(CP_UTF8, 0, src, -1, wbuf, wlen) <= 0)
	{
		delete[] wbuf;
		return false;
	}
	int cplen = WideCharToMultiByte(1251, 0, wbuf, -1, 0, 0, "?", 0);
	if (cplen <= 0)
	{
		delete[] wbuf;
		return false;
	}
	char* cpbuf = new char[cplen];
	if (!cpbuf)
	{
		delete[] wbuf;
		return false;
	}
	if (WideCharToMultiByte(1251, 0, wbuf, -1, cpbuf, cplen, "?", 0) <= 0)
	{
		delete[] cpbuf;
		delete[] wbuf;
		return false;
	}
	strncpy_s(dst, dstSize, cpbuf, _TRUNCATE);
	delete[] cpbuf;
	delete[] wbuf;
	return true;
}

static bool GetSyncPacketPayload(Packet* p, BYTE expectedId, unsigned char** outData, int* outLen)
{
	if (p == 0 || p->data == 0 || p->length <= 0 || outData == 0 || outLen == 0)
		return false;

	unsigned char* data = (unsigned char*)p->data;
	int length = p->length;
	int offset = 0;

	if (data[0] == ID_TIMESTAMP)
	{
		if (length < 1 + 4 + 1)
			return false;
		offset = 1 + 4;
	}

	if (length <= offset || data[offset] != expectedId)
		return false;

	*outData = data + offset;
	*outLen = length - offset;
	return true;
}

static bool ExtractJsonIntFieldLocal(const char* json, const char* key, int* outValue)
{
	if (json == 0 || key == 0 || outValue == 0)
		return false;

	char pattern[32];
	pattern[0] = '\0';
	sprintf_s(pattern, sizeof(pattern), "\"%s\"", key);

	const char* p = strstr(json, pattern);
	if (p == 0)
		return false;
	p += strlen(pattern);

	while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
		++p;
	if (*p != ':')
		return false;
	++p;
	while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
		++p;

	char* endPtr = 0;
	long parsed = strtol(p, &endPtr, 10);
	if (endPtr == p)
		return false;

	*outValue = (int)parsed;
	return true;
}

static bool ExtractJsonStringFieldLocal(const char* json, const char* key, char* out, int outSize)
{
	if (json == 0 || key == 0 || out == 0 || outSize <= 1)
		return false;
	out[0] = '\0';

	char pattern[32];
	pattern[0] = '\0';
	sprintf_s(pattern, sizeof(pattern), "\"%s\"", key);

	const char* p = strstr(json, pattern);
	if (p == 0)
		return false;
	p += strlen(pattern);

	while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
		++p;
	if (*p != ':')
		return false;
	++p;
	while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
		++p;
	if (*p != '"')
		return false;
	++p;

	int i = 0;
	while (*p && *p != '"' && i < outSize - 1)
	{
		if (*p == '\\' && p[1] != '\0')
			++p;
		out[i++] = *p++;
	}
	out[i] = '\0';
	return i > 0;
}

struct BR_REMOTE_PLAYER_SYNC
{
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float vecPos[3];
	float quat[4]; // w, x, y, z
	WORD health;
	WORD armour;
	BYTE weapon;
	BYTE specialAction;
	float vecMoveSpeed[3];
	bool hasSurfInfo;
	WORD wSurfInfo;
	float vecSurfOffsets[3];
	bool hasAnimation;
	DWORD iCurrentAnimationID;
	BYTE unk76;
	BYTE unk77;
};

static bool ReadCompressedQuatBR(RakNet::BitStream& bs, float* outW, float* outX, float* outY, float* outZ)
{
	bool negW, negX, negY, negZ;
	unsigned short sx, sy, sz;
	if (!bs.Read(negW) || !bs.Read(negX) || !bs.Read(negY) || !bs.Read(negZ))
		return false;
	if (!bs.Read(sx) || !bs.Read(sy) || !bs.Read(sz))
		return false;

	float x = (float)sx / 65535.0f;
	float y = (float)sy / 65535.0f;
	float z = (float)sz / 65535.0f;
	if (negX) x = -x;
	if (negY) y = -y;
	if (negZ) z = -z;

	float w2 = 1.0f - x * x - y * y - z * z;
	if (w2 < 0.0f) w2 = 0.0f;
	float w = sqrtf(w2);
	if (negW) w = -w;

	*outW = w;
	*outX = x;
	*outY = y;
	*outZ = z;
	return true;
}

static bool ReadCompressedVectorBR(RakNet::BitStream& bs, float* outX, float* outY, float* outZ)
{
	float magnitude = 0.0f;
	if (!bs.Read(magnitude))
		return false;

	if (magnitude == 0.0f)
	{
		*outX = 0.0f;
		*outY = 0.0f;
		*outZ = 0.0f;
		return true;
	}

	unsigned short sx, sy, sz;
	if (!bs.Read(sx) || !bs.Read(sy) || !bs.Read(sz))
		return false;

	float nx = ((float)sx / 32768.0f) - 1.0f;
	float ny = ((float)sy / 32768.0f) - 1.0f;
	float nz = ((float)sz / 32768.0f) - 1.0f;

	*outX = magnitude * nx;
	*outY = magnitude * ny;
	*outZ = magnitude * nz;
	return true;
}

static bool ReadPlayerSyncBR(RakNet::BitStream& bs, BR_REMOTE_PLAYER_SYNC* out)
{
	if (out == 0)
		return false;

	memset(out, 0, sizeof(BR_REMOTE_PLAYER_SYNC));
	out->wSurfInfo = (WORD)-1;

	bool hasLR = false;
	bool hasUD = false;
	if (!bs.Read(hasLR))
		return false;
	if (hasLR && !bs.Read(out->lrAnalog))
		return false;

	if (!bs.Read(hasUD))
		return false;
	if (hasUD && !bs.Read(out->udAnalog))
		return false;

	if (!bs.Read(out->wKeys))
		return false;
	if (!bs.Read((char*)out->vecPos, sizeof(float) * 3))
		return false;
	if (!ReadCompressedQuatBR(bs, &out->quat[0], &out->quat[1], &out->quat[2], &out->quat[3]))
		return false;
	if (!bs.Read(out->health) || !bs.Read(out->armour))
		return false;
	if (!bs.Read(out->weapon) || !bs.Read(out->specialAction))
		return false;
	if (!ReadCompressedVectorBR(bs, &out->vecMoveSpeed[0], &out->vecMoveSpeed[1], &out->vecMoveSpeed[2]))
		return false;

	bool hasSurf = false;
	if (!bs.Read(hasSurf))
		return false;
	out->hasSurfInfo = hasSurf;
	if (hasSurf)
	{
		if (!bs.Read(out->wSurfInfo))
			return false;
		if (!bs.Read(out->vecSurfOffsets[0]) || !bs.Read(out->vecSurfOffsets[1]) || !bs.Read(out->vecSurfOffsets[2]))
			return false;
	}

	bool hasAnim = false;
	if (!bs.Read(hasAnim))
		return false;
	out->hasAnimation = hasAnim;
	if (hasAnim && !bs.Read(out->iCurrentAnimationID))
		return false;

	if (!bs.Read(out->unk76) || !bs.Read(out->unk77))
		return false;

	return true;
}

bool SendGuiJson(WORD guiId, const char* jsonText, RakClientInterface* pRakClient)
{
	if (pRakClient == 0 || jsonText == 0 || jsonText[0] == '\0')
		return false;

	char jsonCp1251[4096];
	memset(jsonCp1251, 0, sizeof(jsonCp1251));
	if (!Utf8ToCp1251Local(jsonText, jsonCp1251, (int)sizeof(jsonCp1251)))
		strncpy_s(jsonCp1251, sizeof(jsonCp1251), jsonText, _TRUNCATE);

	size_t payloadLen = strnlen_s(jsonCp1251, 4096);
	if (payloadLen == 0 || payloadLen >= 4096)
		return false;

	RakNet::BitStream bsGuiOut;
	bsGuiOut.Write((BYTE)ID_USER_INTERFACE_SYNC);
	bsGuiOut.Write((WORD)guiId);
	bsGuiOut.Write((DWORD)payloadLen);
	bsGuiOut.Write(jsonCp1251, (int)payloadLen);

	pRakClient->Send(&bsGuiOut, HIGH_PRIORITY, RELIABLE_ORDERED, 0);
	return true;
}

static void Packet_UiSync(Packet *p)
{
	if (p == 0 || p->data == 0)
		return;

	unsigned char* payload = 0;
	int packetLen = 0;
	if (!GetSyncPacketPayload(p, ID_USER_INTERFACE_SYNC, &payload, &packetLen))
		return;
	RakNet::BitStream bs(payload, packetLen, false);
	bs.IgnoreBits(8);

	if (bs.GetNumberOfUnreadBits() < (2 + 4) * 8)
		return;

	unsigned short guiId = 0;
	unsigned int payloadLen = 0;

	if (!bs.ReadBits((unsigned char*)&guiId, 16, true))
		return;
	if (!bs.ReadBits((unsigned char*)&payloadLen, 32, true))
		return;
	if (payloadLen == 0 || payloadLen > 4096)
		return;
	if (bs.GetNumberOfUnreadBits() < payloadLen * 8)
		return;

	char jsonCp1251[4097];
	memset(jsonCp1251, 0, sizeof(jsonCp1251));
	bs.Read(jsonCp1251, (int)payloadLen);
	jsonCp1251[payloadLen] = '\0';

	char jsonUtf8[8192];
	memset(jsonUtf8, 0, sizeof(jsonUtf8));
	if (!Cp1251ToUtf8Local(jsonCp1251, jsonUtf8, (int)sizeof(jsonUtf8)))
		strncpy_s(jsonUtf8, sizeof(jsonUtf8), jsonCp1251, _TRUNCATE);

	char jsonForLog[448];
	memset(jsonForLog, 0, sizeof(jsonForLog));
	strncpy_s(jsonForLog, sizeof(jsonForLog), jsonUtf8, _TRUNCATE);

	int tValue = 0;
	bool hasT = ExtractJsonIntFieldLocal(jsonUtf8, "t", &tValue);
	char sValue[64];
	memset(sValue, 0, sizeof(sValue));
	bool hasS = ExtractJsonStringFieldLocal(jsonUtf8, "s", sValue, (int)sizeof(sValue));

	if (hasT && hasS)
		Log("[INTERFACE] guiid=%u t=%d s=%s json=%s", (unsigned int)guiId, tValue, sValue, jsonForLog);
	else if (hasT)
		Log("[INTERFACE] guiid=%u t=%d json=%s", (unsigned int)guiId, tValue, jsonForLog);
	else
		Log("[INTERFACE] guiid=%u json=%s", (unsigned int)guiId, jsonForLog);

	// BR readiness marker from UI flow:
	// gui 38 with t=0 appears after auth stage and before spawn flow.
	if (!g_spawnReadyByCmsg && guiId == 38 && hasT && tValue == 0)
	{
		g_spawnReadyByCmsg = true;
		Log("[SPAWN] UI marker received (guiid=38 t=0): spawn flow is ready.");
	}
	else if (!g_spawnReadyByCmsg && guiId == 111 && hasT && tValue == 5)
	{
		g_spawnReadyByCmsg = true;
		Log("[SPAWN] UI marker received (guiid=111 t=5): spawn flow is ready.");
	}

	// Auto-ack GUI 50 with {"t":1} (rate-limited).
	if (guiId == 50)
	{
		DWORD now = GetTickCount();
		if (now - g_gui50LastAutoReplyTick > 1000)
		{
			if (SendGuiJson(50, "{\"t\":1}", ::pRakClient))
			{
				g_gui50LastAutoReplyTick = now;
				Log("[INTERFACE] auto-reply guiid=50 json={\"t\":1}");
			}
		}
	}

	// Black Russia GUI 111 flow: arm delayed spawn after GUI stream finishes.
	if (guiId == 111)
	{
		g_gui111SpawnPending = true;
		g_gui111LastPacketTick = GetTickCount();
	}
}

const uint64_t unk_189EB8[16] = {
    0x43000000591, 0x3DC0000039F, 0x18400000924, 0x8F000000A34,
    0x915000005B2, 0x5F7000007BC, 0xAC500000A26, 0x5F2000005A7,
    0xC470000057B, 0x54700000D88, 0xC1200000E1C, 0x50E000007DD,
    0xEC600000341, 0x5C10000095D, 0x93000000C61, 0x480000009BA
};

void sub_4D368C(char* out, char* in) {
    size_t inlen;
    char* v4;
    size_t inlen2;
    int v6;
    unsigned char* v7;
    int v8;
    int v9;
    int v10;
    uint32_t v11;
    unsigned int v12;
    char v13;
    unsigned char v14;
    unsigned char* v15;
    unsigned int v16;
    int v17;
    uint32_t v18;
    int v19;
    unsigned int v20;
    int v21;
    int v22;
    char* v23;
    int v24;
    char* out1;
    int v27;
    int v28;
    size_t inlen1;
    int v30;
    int v31;
    uint64_t dest[16];
    int v33;
    char buffer[0x100];

    out1 = out;
    inlen = strlen(in);
    if (inlen <= 0x80) {
        v4 = buffer;

        inlen1 = inlen;
        memcpy(v4, in, inlen + 1);
        v4[inlen1] = 0;
        memcpy(dest, unk_189EB8, sizeof(dest));
        inlen2 = inlen1;

        if (inlen1) {
            v6 = (unsigned __int8)*v4;
            if (*v4) {
                v7 = reinterpret_cast<unsigned char*>(v4);
                v8 = -348;
                v9 = 0;
                v10 = 3 * inlen1 - 34;
                if (!(v6 << 24)) goto LABEL_8;

            LABEL_5:
                v11 = ((uint32_t*)dest)[v9];
                v31 = -347 - v9;
                v30 = v9 - inlen2;
                v12 = 0;
                v27 = v8;
                v13 = 4 * (v9 + inlen2);
                v28 = v9;
                do {
                    v14 = v6 + (v12 >> 5);
                    v15 = v7;
                    v7[v12] = v14 + v13;
                    v16 = v14;
                    v7 = v15;
                    v17 = v31 + v12;
                    v18 = (v14 - inlen1) % (v12 + 0xFFFF);
                    v19 = v18 + v10 - ((v16 - (unsigned __int8)v12 + 2 * v16) >> 24) + v11;
                    v6 = v15[++v12];
                    v20 = (4 * v16 - 32) ^ ((v19 ^ (2 * (v30 + (v16 >> 1)))) >> 1);
                    v11 = v17 + v20;
                    inlen2 = inlen1;
                } while (v6);

                v8 = v27;
                v9 = v28;
                v21 = (v27 + v20 + v12) & 0xFFF;

                while (1) {
                    ((uint32_t*)dest)[v9++] = v21;
                    if (v9 == 32) break;
                    v6 = *v7;
                    --v8;
                    if (v6 << 24) goto LABEL_5;
                LABEL_8:
                    v21 = ((uint32_t*)dest)[v9];
                }
            }
            v22 = 31;
            v23 = out1 + 1;
            do {
                v24 = ((uint32_t*)dest)[v22--];
                v23[1] = (v24 & 0xF) + 67;
                *v23 = ((v24 >> 4) & 0xF) + 66;
                v23 += 3;
                *(v23 - 4) = ((v24 >> 8) & 0xF) + 65;
            } while (v22 != -1);
            out1[96] = 0;
        }
    }
}

void Packet_AUTH_KEY(Packet *p, RakClientInterface *pRakClient)
{
    if (p == 0 || p->data == 0 || p->length < 2)
        return;

    if (iAreWeConnected || g_authKeyHandled)
        return;

    RakNet::BitStream bsAuth(p->data, p->length, false);

    BYTE byteAuthLen;
    char szAuthIn[260];
    char szAuthKeyOut[260];

    bsAuth.IgnoreBits(8); // ID_AUTH_KEY
    bsAuth.Read(byteAuthLen);
    if ((unsigned int)(2 + byteAuthLen) != p->length)
        return;
    if (byteAuthLen == 0 || byteAuthLen > 0x80)
        return;

    int safeAuthLen = (int)byteAuthLen;
    if (safeAuthLen >= (int)sizeof(szAuthIn))
    {
        safeAuthLen = (int)sizeof(szAuthIn) - 1;
    }

    bsAuth.Read(szAuthIn, safeAuthLen);
    if ((int)byteAuthLen > safeAuthLen)
        bsAuth.IgnoreBits(((int)byteAuthLen - safeAuthLen) * 8);
    szAuthIn[safeAuthLen] = '\0';

    for (int i = 0; i < safeAuthLen; i++)
    {
        if (!IsAuthTokenChar(szAuthIn[i]))
            return;
    }

    memset(szAuthKeyOut, 0, sizeof(szAuthKeyOut));
    sub_4D368C(szAuthKeyOut, szAuthIn);

    RakNet::BitStream bsKey;
    BYTE byteAuthKeyLen = (BYTE)strlen(szAuthKeyOut);

    bsKey.Write((BYTE)ID_AUTH_KEY);
    bsKey.Write(byteAuthKeyLen);
    bsKey.Write(szAuthKeyOut, byteAuthKeyLen);

    pRakClient->Send(&bsKey, SYSTEM_PRIORITY, RELIABLE, NULL);
    g_authKeyHandled = true;
}

void Packet_ConnectionSucceeded(Packet *p, RakClientInterface *pRakClient)
{
    RakNet::BitStream bsSuccAuth((unsigned char *)p->data, p->length, false);
    unsigned int uiChallenge;

    bsSuccAuth.IgnoreBits(8); // ID_CONNECTION_REQUEST_ACCEPTED
    bsSuccAuth.Read(uiChallenge); 
    bsSuccAuth.IgnoreBits(16); 

    g_myPlayerID = 2; 
    playerInfo[g_myPlayerID].iIsConnected = 1;
    strncpy_s(playerInfo[g_myPlayerID].szPlayerName, sizeof(playerInfo[g_myPlayerID].szPlayerName), g_szNickName, _TRUNCATE);
    settings.uiChallange = uiChallenge;

    int iVersion = 0xFDE;
    unsigned int uiClientChallengeResponse = uiChallenge ^ iVersion;
    BYTE byteNameLen = (BYTE)strlen(g_szNickName);

    RakNet::BitStream bsSend;
    
    bsSend.Write(uiClientChallengeResponse);
    BYTE androidVersion = 1;
    bsSend.Write(androidVersion);
    int clientver = 1362;
    bsSend.Write(clientver);
    BYTE fingerPrint = 0;
    bsSend.Write(fingerPrint);
    bsSend.Write(byteNameLen);
    bsSend.Write(g_szNickName, byteNameLen);

    pRakClient->RPC(&RPC_ClientJoin, &bsSend, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);

    iAreWeConnected = 1;
}

void Packet_PlayerSync(Packet *p, RakClientInterface *pRakClient)
{
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_PLAYER_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsPlayerSync(payload, payloadLen, false);
	bsPlayerSync.IgnoreBits(8);
	PLAYERID playerId;

	//Log("Packet_PlayerSync: %d \n%s\n", p->length, DumpMem((unsigned char *)p->data, p->length));

	bsPlayerSync.Read(playerId);

	if(playerId < 0 || playerId >= MAX_PLAYERS) return;

	// Followed passenger exit
	if(settings.runMode == RUNMODE_FOLLOWPLAYER && playerId == getPlayerIDFromPlayerName(settings.szFollowingPlayerName))
	{
		if(iPassengerNotificationSent)
		{
			SendExitVehicleNotification(playerInfo[playerId].incarData.VehicleID);
			iPassengerNotificationSent = 0;
		}

		iFollowingPassenger = 0;

		if(iDriverNotificationSent)
		{
			SendExitVehicleNotification(playerInfo[playerId].incarData.VehicleID);
			iDriverNotificationSent = 0;
		}

		iFollowingDriver = 0;
	}
	playerInfo[playerId].incarData.VehicleID = -1;


	BR_REMOTE_PLAYER_SYNC remoteSync;
	if (!ReadPlayerSyncBR(bsPlayerSync, &remoteSync))
		return;

	// clear last data
	memset(&playerInfo[playerId].onfootData, 0, sizeof(ONFOOT_SYNC_DATA));

	playerInfo[playerId].onfootData.lrAnalog = remoteSync.lrAnalog;
	playerInfo[playerId].onfootData.udAnalog = remoteSync.udAnalog;
	playerInfo[playerId].onfootData.wKeys = remoteSync.wKeys;
	playerInfo[playerId].onfootData.vecPos[0] = remoteSync.vecPos[0];
	playerInfo[playerId].onfootData.vecPos[1] = remoteSync.vecPos[1];
	playerInfo[playerId].onfootData.vecPos[2] = remoteSync.vecPos[2];
	playerInfo[playerId].onfootData.fQuaternion[0] = remoteSync.quat[0];
	playerInfo[playerId].onfootData.fQuaternion[1] = remoteSync.quat[1];
	playerInfo[playerId].onfootData.fQuaternion[2] = remoteSync.quat[2];
	playerInfo[playerId].onfootData.fQuaternion[3] = remoteSync.quat[3];
	playerInfo[playerId].onfootData.byteHealth = (BYTE)((remoteSync.health > 255) ? 255 : remoteSync.health);
	playerInfo[playerId].onfootData.byteArmour = (BYTE)((remoteSync.armour > 255) ? 255 : remoteSync.armour);
	playerInfo[playerId].onfootData.byteCurrentWeapon = remoteSync.weapon;
	playerInfo[playerId].onfootData.byteSpecialAction = remoteSync.specialAction;
	playerInfo[playerId].onfootData.vecMoveSpeed[0] = remoteSync.vecMoveSpeed[0];
	playerInfo[playerId].onfootData.vecMoveSpeed[1] = remoteSync.vecMoveSpeed[1];
	playerInfo[playerId].onfootData.vecMoveSpeed[2] = remoteSync.vecMoveSpeed[2];
	playerInfo[playerId].onfootData.wSurfInfo = remoteSync.hasSurfInfo ? remoteSync.wSurfInfo : (WORD)-1;
	playerInfo[playerId].onfootData.vecSurfOffsets[0] = remoteSync.vecSurfOffsets[0];
	playerInfo[playerId].onfootData.vecSurfOffsets[1] = remoteSync.vecSurfOffsets[1];
	playerInfo[playerId].onfootData.vecSurfOffsets[2] = remoteSync.vecSurfOffsets[2];
	playerInfo[playerId].onfootData.iCurrentAnimationID = remoteSync.hasAnimation ? (int)remoteSync.iCurrentAnimationID : 0;
}

//----------------------------------------------------

void Packet_UnoccupiedSync(Packet *p, RakClientInterface *pRakClient)
{
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_UNOCCUPIED_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsUnocSync(payload, payloadLen, false);
	bsUnocSync.IgnoreBits(8);
	PLAYERID playerId;

	//Log("\n%s\n", DumpMem((unsigned char *)p->data + bsUnocSync.GetReadOffset() / 8, p->length));

	bsUnocSync.Read(playerId);

	if(playerId < 0 || playerId >= MAX_PLAYERS) return;

	memset(&playerInfo[playerId].unocData, 0, sizeof(UNOCCUPIED_SYNC_DATA));

	bsUnocSync.Read((char *)&playerInfo[playerId].unocData, sizeof(UNOCCUPIED_SYNC_DATA));
}

void Packet_AimSync(Packet *p, RakClientInterface *pRakClient)
{  
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_AIM_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsAimSync(payload, payloadLen, false);
	bsAimSync.IgnoreBits(8);
	PLAYERID playerId;

	//Log("Packet_AimSync:\n%s\n", DumpMem((unsigned char *)p->data, p->length));

	bsAimSync.Read(playerId);

	if(playerId < 0 || playerId >= MAX_PLAYERS) return;

	memset(&playerInfo[playerId].aimData, 0, sizeof(AIM_SYNC_DATA));

	bsAimSync.Read((PCHAR)&playerInfo[playerId].aimData, sizeof(AIM_SYNC_DATA));
}

void Packet_VehicleSync(Packet *p, RakClientInterface *pRakClient)
{
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_VEHICLE_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsSync(payload, payloadLen, false);
	bsSync.IgnoreBits(8);
	PLAYERID playerId;

	VEHICLEID VehicleID;
	bool bLandingGear;
	bool bHydra,bTrain,bTrailer;
	bool bSiren;

	//Log("Packet_VehicleSync: %d \n%s\n", p->length, DumpMem((unsigned char *)p->data, p->length));

	bsSync.Read(playerId);
	bsSync.Read(VehicleID);

	if(playerId < 0 || playerId >= MAX_PLAYERS) return;
	if(VehicleID < 0 || VehicleID >= MAX_VEHICLES) return;

	// Follower passenger enter
	playerInfo[playerId].incarData.VehicleID = VehicleID;
	if(settings.runMode == RUNMODE_FOLLOWPLAYER && playerId == getPlayerIDFromPlayerName(settings.szFollowingPlayerName))
	{
		if(!iPassengerNotificationSent)
		{
			SendEnterVehicleNotification(VehicleID, 1);
			iPassengerNotificationSent = 1;
		}
		
		SendPassengerFullSyncData(VehicleID);
		iFollowingPassenger = 1;
		return;
	}


	// clear last data
	memset(&playerInfo[playerId].incarData, 0, sizeof(INCAR_SYNC_DATA));

	// LEFT/RIGHT KEYS
	bsSync.Read(playerInfo[playerId].incarData.lrAnalog);

	// UP/DOWN KEYS
	bsSync.Read(playerInfo[playerId].incarData.udAnalog);

	// GENERAL KEYS
	bsSync.Read(playerInfo[playerId].incarData.wKeys);

	// ROLL / DIRECTION
	// ROTATION
	bsSync.ReadNormQuat(
		playerInfo[playerId].incarData.fQuaternion[0],
		playerInfo[playerId].incarData.fQuaternion[1],
		playerInfo[playerId].incarData.fQuaternion[2],
		playerInfo[playerId].incarData.fQuaternion[3]);

	// POSITION
	bsSync.Read(playerInfo[playerId].incarData.vecPos[0]);
	bsSync.Read(playerInfo[playerId].incarData.vecPos[1]);
	bsSync.Read(playerInfo[playerId].incarData.vecPos[2]);

	// SPEED
	bsSync.ReadVector(
		playerInfo[playerId].incarData.vecMoveSpeed[0],
		playerInfo[playerId].incarData.vecMoveSpeed[1],
		playerInfo[playerId].incarData.vecMoveSpeed[2]);

	// VEHICLE HEALTH
	WORD wTempVehicleHealth;
	bsSync.Read(wTempVehicleHealth);
	playerInfo[playerId].incarData.fCarHealth = (float)wTempVehicleHealth;

	// HEALTH/ARMOUR (COMPRESSED INTO 1 BYTE)
	BYTE byteHealthArmour;
	BYTE bytePlayerHealth, bytePlayerArmour;
	BYTE byteArmTemp=0,byteHlTemp=0;

	bsSync.Read(byteHealthArmour);
	byteArmTemp = (byteHealthArmour & 0x0F);
	byteHlTemp = (byteHealthArmour >> 4);

	if(byteArmTemp == 0xF) bytePlayerArmour = 100;
	else if(byteArmTemp == 0) bytePlayerArmour = 0;
	else bytePlayerArmour = byteArmTemp * 7;

	if(byteHlTemp == 0xF) bytePlayerHealth = 100;
	else if(byteHlTemp == 0) bytePlayerHealth = 0;
	else bytePlayerHealth = byteHlTemp * 7;

	playerInfo[playerId].incarData.bytePlayerHealth = bytePlayerHealth;
	playerInfo[playerId].incarData.bytePlayerArmour = bytePlayerArmour;

	// CURRENT WEAPON
	bsSync.Read(playerInfo[playerId].incarData.byteCurrentWeapon);

	// SIREN
	bsSync.ReadCompressed(bSiren);
	if(bSiren)
		playerInfo[playerId].incarData.byteSirenOn = 1;

	// LANDING GEAR
	bsSync.ReadCompressed(bLandingGear);
	if(bLandingGear)
		playerInfo[playerId].incarData.byteLandingGearState = 1;

	// HYDRA THRUST ANGLE AND TRAILER ID
	bsSync.ReadCompressed(bHydra);
	bsSync.ReadCompressed(bTrailer);

	DWORD dwTrailerID_or_ThrustAngle;
	bsSync.Read(dwTrailerID_or_ThrustAngle);
	playerInfo[playerId].incarData.TrailerID_or_ThrustAngle = (WORD)dwTrailerID_or_ThrustAngle;

	// TRAIN SPECIAL
	WORD wSpeed;
	bsSync.ReadCompressed(bTrain);
	if(bTrain)
	{
		bsSync.Read(wSpeed);
		playerInfo[playerId].incarData.fTrainSpeed = (float)wSpeed;
	}
}

void Packet_PassengerSync(Packet *p, RakClientInterface *pRakClient)
{
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_PASSENGER_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsPassengerSync(payload, payloadLen, false);
	bsPassengerSync.IgnoreBits(8);
	PLAYERID	playerId;
	PASSENGER_SYNC_DATA psSync;

	bsPassengerSync.Read(playerId);

	if(playerId < 0 || playerId >= MAX_PLAYERS) return;

	bsPassengerSync.Read((PCHAR)&psSync,sizeof(PASSENGER_SYNC_DATA));

	// Followed wants to drive the vehicle
	playerInfo[playerId].passengerData.VehicleID = psSync.VehicleID;
	if(settings.runMode == RUNMODE_FOLLOWPLAYER && playerId == getPlayerIDFromPlayerName(settings.szFollowingPlayerName))
	{
		if(!iDriverNotificationSent)
		{
			SendEnterVehicleNotification(psSync.VehicleID, 0);
			iDriverNotificationSent = 1;
		}

		INCAR_SYNC_DATA icSync;
		memset(&icSync, 0, sizeof(INCAR_SYNC_DATA));
		icSync.VehicleID = psSync.VehicleID;
		icSync.fCarHealth = 1000.00f;
		icSync.bytePlayerHealth = (BYTE)settings.fPlayerHealth;
		icSync.bytePlayerArmour = (BYTE)settings.fPlayerArmour;
		SendInCarFullSyncData(&icSync, 1, -1);

		iFollowingDriver = 1;
		return;
	}
}

void Packet_TrailerSync(Packet *p, RakClientInterface *pRakClient)
{
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_TRAILER_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsSpectatorSync(payload, payloadLen, false);
	bsSpectatorSync.IgnoreBits(8);

	PLAYERID playerId;
	//TRAILER_SYNC_DATA trSync;

	bsSpectatorSync.Read(playerId);
	//bsSpectatorSync.Read((PCHAR)&trSync, sizeof(TRAILER_SYNC_DATA));
}

void Packet_MarkersSync(Packet *p, RakClientInterface *pRakClient)
{
	unsigned char* payload = 0;
	int payloadLen = 0;
	if (!GetSyncPacketPayload(p, ID_MARKERS_SYNC, &payload, &payloadLen))
		return;
	RakNet::BitStream bsMarkersSync(payload, payloadLen, false);
	bsMarkersSync.IgnoreBits(8);

	int i, iNumberOfPlayers;
	PLAYERID playerID;
	short sPosX, sPosY, sPosZ;
	bool bIsPlayerActive;

	bsMarkersSync.Read(iNumberOfPlayers);

	if(iNumberOfPlayers < 0 || iNumberOfPlayers > MAX_PLAYERS) return;

	for(i = 0; i < iNumberOfPlayers; i++)
	{
		bsMarkersSync.Read(playerID);

		if(playerID < 0 || playerID >= MAX_PLAYERS) return;

		bsMarkersSync.ReadCompressed(bIsPlayerActive);
		if(bIsPlayerActive == 0)
		{
			playerInfo[playerID].iGotMarkersPos = 0;
			continue;
		}

		bsMarkersSync.Read(sPosX);
		bsMarkersSync.Read(sPosY);
		bsMarkersSync.Read(sPosZ);

		playerInfo[playerID].iGotMarkersPos = 1;
		playerInfo[playerID].onfootData.vecPos[0] = (float)sPosX;
		playerInfo[playerID].onfootData.vecPos[1] = (float)sPosY;
		playerInfo[playerID].onfootData.vecPos[2] = (float)sPosZ;

		//Log("Packet_MarkersSync: %d %d %0.2f, %0.2f, %0.2f", playerID, bIsPlayerActive, (float)sPosX, (float)sPosY, (float)sPosZ);
	}
}

void Packet_BulletSync(Packet *p, RakClientInterface *pRakClient)
{
	if(m_bLagCompensation)
	{
		unsigned char* payload = 0;
		int payloadLen = 0;
		if (!GetSyncPacketPayload(p, ID_BULLET_SYNC, &payload, &payloadLen))
			return;
		RakNet::BitStream bsBulletSync(payload, payloadLen, false);
		bsBulletSync.IgnoreBits(8);

		PLAYERID PlayerID;
		bsBulletSync.Read(PlayerID);

		if(PlayerID < 0 || PlayerID >= MAX_PLAYERS) return;

		memset(&playerInfo[PlayerID].bulletData, 0, sizeof(BULLET_SYNC_DATA));

		bsBulletSync.Read((PCHAR)&playerInfo[PlayerID].bulletData, sizeof(BULLET_SYNC_DATA));

		PLAYERID copyingID = getPlayerIDFromPlayerName(settings.szFollowingPlayerName);

		if(copyingID != (PLAYERID)-1 && (settings.runMode == RUNMODE_FOLLOWPLAYER || settings.runMode == RUNMODE_FOLLOWPLAYERSVEHICLE))
		{
			if(copyingID == PlayerID)
				SendBulletData(&playerInfo[PlayerID].bulletData);
		}
	}
}

void resetPools(int iRestart, DWORD dwTimeReconnect)
{
	memset(playerInfo, 0, sizeof(stPlayerInfo));
	memset(vehiclePool, 0, sizeof(stVehiclePool));
	memset(&SpawnInfo, 0, sizeof(SpawnInfo));
	g_spawnReadyByCmsg = false;
	g_forceSpawnInfoOnFirstSync = false;
	g_dwLastRpcSetPlayerPosTick = 0;
	g_dwLastScrSetSpawnInfoTick = 0;
	g_dwSpawnFirstSyncUnlockTick = 0;
	g_autoSpawnClassRequestInFlight = false;
	g_autoSpawnAwaitingSpawnConfirm = false;
	g_spawnAllowNoCoordsOnce = false;
	g_dwSpawnHandshakeTick = 0;
	g_gui111SpawnPending = false;
	g_gui111LastPacketTick = 0;
	g_spawnClassRetryTick = 0;
	g_spawnWaitLogTick = 0;
	g_gui50LastAutoReplyTick = 0;
	g_pkt9WindowTick = 0;
	g_pkt9WindowCount = 0;
	g_pkt9LastLen = 0;
	g_pkt9LastTs = 0;

	if(iRestart)
	{
		iAreWeConnected = 0;
		iConnectionRequested = 0;
		iSpawned = 0;
		iMoney = 0;
		iDrunkLevel = 0;
		iLocalPlayerSkin = 0;

		settings.bPulsator = false;

		settings.fPlayerHealth = 100.0f;
		settings.fPlayerArmour = 0.0f;

		Sleep(dwTimeReconnect);
	}
}

void UpdatePlayerScoresAndPings(int iWait, int iMS, RakClientInterface *pRakClient)
{
	static DWORD dwLastUpdateTick = 0;

	if(iWait)
	{
		if ((GetTickCount() - dwLastUpdateTick) > (DWORD)iMS)
		{
			dwLastUpdateTick = GetTickCount();
			RakNet::BitStream bsParams;
			pRakClient->RPC(&RPC_UpdateScoresPingsIPs, &bsParams, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
		}
	}
	else
	{
		RakNet::BitStream bsParams;
		pRakClient->RPC(&RPC_UpdateScoresPingsIPs, &bsParams, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
	}
}

void UpdateNetwork(RakClientInterface *pRakClient)
{
	unsigned char packetIdentifier;
	Packet *pkt;

	while(pkt = pRakClient->Receive())
	{
		if ( ( unsigned char ) pkt->data[ 0 ] == ID_TIMESTAMP )
		{
			if ( pkt->length > sizeof( unsigned char ) + sizeof( unsigned int ) )
				packetIdentifier = ( unsigned char ) pkt->data[ sizeof( unsigned char ) + sizeof( unsigned int ) ];
			else
				return;
		}
		else
			packetIdentifier = ( unsigned char ) pkt->data[ 0 ];

		if(packetIdentifier == 9)
		{
			DWORD now = GetTickCount();
			if(g_pkt9WindowTick == 0)
				g_pkt9WindowTick = now;

			g_pkt9WindowCount++;
			g_pkt9LastLen = pkt->length;
			g_pkt9LastTs = ((unsigned char)pkt->data[0] == ID_TIMESTAMP) ? 1 : 0;

			if(now - g_pkt9WindowTick >= 1000)
			{
				Log("[PKT9] rate=%d/s last_len=%d ts=%d", g_pkt9WindowCount, g_pkt9LastLen, g_pkt9LastTs);
				g_pkt9WindowTick = now;
				g_pkt9WindowCount = 0;
			}
		}

		//Log("[RAKSAMP] Packet received. PacketID: %d.", pkt->data[0]);
		switch(packetIdentifier)
		{
			case ID_DISCONNECTION_NOTIFICATION:
				if (pRakClient == ::pRakClient)
				{
                    g_authKeyHandled = false;
					Log("[RAKSAMP] Connection was closed by the server. Reconnecting in %d seconds.", iReconnectTime / 1000);
					resetPools(1, iReconnectTime);
				}
				break;
			case ID_CONNECTION_BANNED:
				if (pRakClient == ::pRakClient)
				{
                    g_authKeyHandled = false;
					Log("[RAKSAMP] You are banned. Reconnecting in %d seconds.", iReconnectTime / 1000);
					resetPools(1, iReconnectTime);
				}
				break;			
			case ID_CONNECTION_ATTEMPT_FAILED:
				if (pRakClient == ::pRakClient)
				{
                    g_authKeyHandled = false;
					Log("[RAKSAMP] Connection attempt failed. Reconnecting in %d seconds.", iReconnectTime / 1000);
					resetPools(1, iReconnectTime);
				}
				break;
			case ID_NO_FREE_INCOMING_CONNECTIONS:
				if (pRakClient == ::pRakClient)
				{
                    g_authKeyHandled = false;
					Log("[RAKSAMP] The server is full. Reconnecting in %d seconds.", iReconnectTime / 1000);
					resetPools(1, iReconnectTime);
				}
				break;
			case ID_INVALID_PASSWORD:
				if (pRakClient == ::pRakClient)
				{
                    g_authKeyHandled = false;
					Log("[RAKSAMP] Invalid password. Reconnecting in %d seconds.", iReconnectTime / 1000);
					resetPools(1, iReconnectTime);
				}
				break;
			case ID_CONNECTION_LOST:
				if (pRakClient == ::pRakClient)
				{
                    g_authKeyHandled = false;
					Log("[RAKSAMP] The connection was lost. Reconnecting in %d seconds.", iReconnectTime / 1000);
					resetPools(1, iReconnectTime);
				}
				break;
			case ID_CONNECTION_REQUEST_ACCEPTED:
				Packet_ConnectionSucceeded(pkt, pRakClient);
				break;
			case ID_AUTH_KEY:
				Packet_AUTH_KEY(pkt, pRakClient);
				break;
			case ID_USER_INTERFACE_SYNC:
				Packet_UiSync(pkt);
				break;
			case ID_PLAYER_SYNC:
				Packet_PlayerSync(pkt, pRakClient);
				break;
			case ID_VEHICLE_SYNC:
				Packet_VehicleSync(pkt, pRakClient);
				break;
			case ID_PASSENGER_SYNC:
				Packet_PassengerSync(pkt, pRakClient);
				break;
			case ID_AIM_SYNC:
				Packet_AimSync(pkt, pRakClient);
				break;
			case ID_TRAILER_SYNC:
				Packet_TrailerSync(pkt, pRakClient);
				break;
			case ID_UNOCCUPIED_SYNC:
				Packet_UnoccupiedSync(pkt, pRakClient);
				break;
			case ID_MARKERS_SYNC:
				Packet_MarkersSync(pkt, pRakClient);
				break;
			case ID_BULLET_SYNC:
				Packet_BulletSync(pkt, pRakClient);
				break;
		}

		pRakClient->DeallocatePacket(pkt);
	}

	// Spawn only after GUI 111 packets stop for a short period.
	if (g_gui111SpawnPending && !iSpawned && iAreWeConnected && iGameInited && pRakClient && pRakClient->IsConnected())
	{
		DWORD now = GetTickCount();
		const bool guiFinished = (g_gui111LastPacketTick != 0 && now - g_gui111LastPacketTick > 1200);
		const bool hasValidSpawnInfo =
			(g_dwLastScrSetSpawnInfoTick != 0 &&
			 now - g_dwLastScrSetSpawnInfoTick < 8000 &&
			 (SpawnInfo.vecPos[0] != 0.0f || SpawnInfo.vecPos[1] != 0.0f || SpawnInfo.vecPos[2] != 0.0f));
		const bool hasCurrentPos =
			(settings.fNormalModePos[0] != 0.0f || settings.fNormalModePos[1] != 0.0f || settings.fNormalModePos[2] != 0.0f);
		const bool hasRecentSetPlayerPos =
			(g_dwLastRpcSetPlayerPosTick != 0 &&
			 now - g_dwLastRpcSetPlayerPosTick < 15000 &&
			 hasCurrentPos);
		const bool canSpawnByCmsgMarker = g_spawnReadyByCmsg;

		if (guiFinished && canSpawnByCmsgMarker && (hasValidSpawnInfo || hasRecentSetPlayerPos))
		{
			if(!g_autoSpawnClassRequestInFlight && !g_autoSpawnAwaitingSpawnConfirm)
			{
				sampRequestClass(settings.iClassID);
				g_autoSpawnClassRequestInFlight = true;
				g_spawnClassRetryTick = now;
				Log("[SPAWN] Auto-spawn: RequestClass sent, waiting RPC_RequestClass.");
			}
			else if(g_autoSpawnClassRequestInFlight && (g_spawnClassRetryTick == 0 || now - g_spawnClassRetryTick >= 3000))
			{
				sampRequestClass(settings.iClassID);
				g_spawnClassRetryTick = now;
				Log("[SPAWN] RequestClass retry (waiting class outcome).");
			}
		}
		else if (canSpawnByCmsgMarker && guiFinished)
		{
			// Some BR flows require repeated class request before SpawnInfo arrives.
			if (!g_autoSpawnAwaitingSpawnConfirm &&
				(g_spawnClassRetryTick == 0 || now - g_spawnClassRetryTick >= 1500))
			{
				sampRequestClass(settings.iClassID);
				g_autoSpawnClassRequestInFlight = true;
				g_spawnClassRetryTick = now;
			}

			if (g_spawnWaitLogTick == 0 || now - g_spawnWaitLogTick >= 2000)
			{
				Log("[SPAWN] Waiting for spawn coords (ScrSetSpawnInfo/ScrSetPlayerPos), retrying RequestClass...");
				g_spawnWaitLogTick = now;
			}
		}
	}
	else if (iSpawned)
	{
		g_gui111SpawnPending = false;
		g_gui111LastPacketTick = 0;
		g_spawnClassRetryTick = 0;
		g_spawnWaitLogTick = 0;
		g_autoSpawnClassRequestInFlight = false;
		g_autoSpawnAwaitingSpawnConfirm = false;
		g_dwSpawnHandshakeTick = 0;
	}

	UpdatePlayerScoresAndPings(1, 3000, pRakClient);
}
