/*
	Updated to 0.3.7 by P3ti
*/

void resetPools(int iRestart, DWORD dwTimeReconnect);
void UpdatePlayerScoresAndPings(int iWait, int iMS, RakClientInterface *pRakClient);
void UpdateNetwork(RakClientInterface *pRakClient);
bool SendGuiJson(WORD guiId, const char *jsonText, RakClientInterface *pRakClient);
