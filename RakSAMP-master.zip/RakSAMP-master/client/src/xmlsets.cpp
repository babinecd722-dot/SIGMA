/*
	Updated to 0.3.7 by P3ti
*/

#include "main.h"

struct stSettings settings;
TiXmlDocument xmlSettings;

static void SetDefaultSettings()
{
	memset(&settings, 0, sizeof(settings));

	strcpy_s(settings.server.szAddr, sizeof(settings.server.szAddr), "127.0.0.1");
	settings.server.iPort = 7777;
	strcpy_s(settings.server.szNickname, sizeof(settings.server.szNickname), "RakLite");
	settings.server.szPassword[0] = '\0';

	settings.iConsole = 0;
	settings.runMode = RUNMODE_NORMAL;
	settings.iAutorun = 0;
	settings.iFind = 0;
	settings.iClassID = 0;
	settings.iManualSpawn = 0;
	settings.iPrintTimestamps = 1;

	settings.iUpdateStats = 1;
	settings.iMinFPS = 35;
	settings.iMaxFPS = 90;

	strcpy_s(settings.szClientVersion, sizeof(settings.szClientVersion), "0.3.7");

	settings.bChatColorRed = 0;
	settings.bChatColorGreen = 200;
	settings.bChatColorBlue = 0;
	settings.bCMsgRed = 0;
	settings.bCMsgGreen = 170;
	settings.bCMsgBlue = 255;
	settings.bCPAlertRed = 255;
	settings.bCPAlertGreen = 140;
	settings.bCPAlertBlue = 0;

	settings.fPlayerHealth = 100.0f;
	settings.fPlayerArmour = 0.0f;
	settings.CurrentCheckpoint.bActive = false;
	settings.uiForceCustomSendRates = 0;
}

static void BuildModuleFilePath(const char* extension, char* outPath, size_t outSize)
{
	if (outPath == 0 || outSize == 0)
		return;
	outPath[0] = '\0';

	char modulePath[MAX_PATH];
	if (GetModuleFileNameA(NULL, modulePath, MAX_PATH) == 0)
		return;

	char* dot = strrchr(modulePath, '.');
	if (dot != 0)
		*dot = '\0';

	if (extension == 0)
		extension = "";

	sprintf_s(outPath, outSize, "%s%s", modulePath, extension);
}

int LoadSettings()
{
	SetDefaultSettings();

	char moduleXml[MAX_PATH];
	BuildModuleFilePath(".xml", moduleXml, sizeof(moduleXml));

	bool hasXml = false;

	// load xml (prefer config with the same base name as exe)
	if(xmlSettings.LoadFile(moduleXml) ||
	   xmlSettings.LoadFile("RakSAMP Lite.xml") ||
	   xmlSettings.LoadFile("RakSAMPClient.xml"))
	{
		hasXml = true;
	}

	TiXmlElement* rakSAMPElement = 0;
	if(hasXml)
	{
		rakSAMPElement = xmlSettings.FirstChildElement("RakSAMPClient");
		if(!rakSAMPElement)
			rakSAMPElement = xmlSettings.FirstChildElement("RakSAMPLite");
		if(!rakSAMPElement)
			rakSAMPElement = xmlSettings.FirstChildElement("RakSAMP");
	}

	if(rakSAMPElement != 0)
	{
		// get console
		rakSAMPElement->QueryIntAttribute("console", (int *)&settings.iConsole);

		// get runmode
		rakSAMPElement->QueryIntAttribute("runmode", (int *)&settings.runMode);

		// get autorun
		rakSAMPElement->QueryIntAttribute("autorun", (int *)&settings.iAutorun);

		// get find
		rakSAMPElement->QueryIntAttribute("find", (int *)&settings.iFind);

		// get selected class id
		rakSAMPElement->QueryIntAttribute("select_classid", (int *)&settings.iClassID);

		// get manual spawn
		rakSAMPElement->QueryIntAttribute("manual_spawn", (int *)&settings.iManualSpawn);

		// get print_timestamps
		rakSAMPElement->QueryIntAttribute("print_timestamps", (int *)&settings.iPrintTimestamps);

		// get fps simulation
		rakSAMPElement->QueryIntAttribute("updatestats", (int *)&settings.iUpdateStats);

		// get min simulated fps
		rakSAMPElement->QueryIntAttribute("minfps", (int *)&settings.iMinFPS);

		// get max simulated fps
		rakSAMPElement->QueryIntAttribute("maxfps", (int *)&settings.iMaxFPS);

		// get client version
		strcpy(settings.szClientVersion, (char *)rakSAMPElement->Attribute("clientversion"));

		// get chat color
		rakSAMPElement->QueryColorAttribute("chatcolor_rgb",
			(unsigned char *)&settings.bChatColorRed, (unsigned char *)&settings.bChatColorGreen, (unsigned char *)&settings.bChatColorBlue);

		// get client message color
		rakSAMPElement->QueryColorAttribute("clientmsg_rgb",
			(unsigned char *)&settings.bCMsgRed, (unsigned char *)&settings.bCMsgGreen, (unsigned char *)&settings.bCMsgBlue);
		
		// get checkpoint alert color
		rakSAMPElement->QueryColorAttribute("cpalert_rgb",
			(unsigned char *)&settings.bCPAlertRed, (unsigned char *)&settings.bCPAlertGreen, (unsigned char *)&settings.bCPAlertBlue);

		// get followplayer
		strcpy(settings.szFollowingPlayerName, (char *)rakSAMPElement->Attribute("followplayer"));
		rakSAMPElement->QueryIntAttribute("followplayerwithvehicleid", &settings.iFollowingWithVehicleID);
		rakSAMPElement->QueryFloatAttribute("followXOffset", &settings.fFollowXOffset);
		rakSAMPElement->QueryFloatAttribute("followYOffset", &settings.fFollowYOffset);
		rakSAMPElement->QueryFloatAttribute("followZOffset", &settings.fFollowZOffset);

		// get the first server
		TiXmlElement* serverElement = rakSAMPElement->FirstChildElement("server");
		if(serverElement)
		{
			char *pszAddr = (char *)serverElement->GetText();
			if(pszAddr)
			{
				int iPort;
				char *pszAddrBak = pszAddr;

				while(*pszAddrBak)
				{
					if(*pszAddrBak == ':')
					{
						*pszAddrBak = 0;
						pszAddrBak++;
						iPort = atoi(pszAddrBak);
					}
					pszAddrBak++;
				}

				strcpy(settings.server.szAddr, pszAddr);
				settings.server.iPort = iPort;
				strcpy(settings.server.szNickname, (char *)serverElement->Attribute("nickname"));
				strcpy(settings.server.szPassword, (char *)serverElement->Attribute("password"));
			}
		}

		// get intervals
		TiXmlElement* intervalsElement = rakSAMPElement->FirstChildElement("intervals");
		if(intervalsElement)
		{
			intervalsElement->QueryIntAttribute("spam", (int *)&settings.uiSpamInterval);
			intervalsElement->QueryIntAttribute("fakekill", (int *)&settings.uiFakeKillInterval);
			intervalsElement->QueryIntAttribute("lag", (int *)&settings.uiLagInterval);
			intervalsElement->QueryIntAttribute("joinflood", (int *)&settings.uiJoinFloodInterval);
			intervalsElement->QueryIntAttribute("chatflood", (int *)&settings.uiChatFloodInterval);
			intervalsElement->QueryIntAttribute("classflood", (int *)&settings.uiClassFloodInterval);
			intervalsElement->QueryIntAttribute("bulletflood", (int *)&settings.uiBulletFloodInterval);
		}

		// get logging settings
		TiXmlElement* logElement = rakSAMPElement->FirstChildElement("log");
		if(logElement)
		{
			logElement->QueryIntAttribute("objects", (int *)&settings.uiObjectsLogging);
			logElement->QueryIntAttribute("pickups", (int *)&settings.uiPickupsLogging);
			logElement->QueryIntAttribute("textlabels", (int *)&settings.uiTextLabelsLogging);
			logElement->QueryIntAttribute("textdraws", (int *)&settings.uiTextDrawsLogging);
		}

		// get sendrates settings
		TiXmlElement* sendratesElement = rakSAMPElement->FirstChildElement("sendrates");
		if(sendratesElement)
		{
			sendratesElement->QueryIntAttribute("force", (int *)&settings.uiForceCustomSendRates);
			sendratesElement->QueryIntAttribute("onfoot", (int *)&iNetModeNormalOnfootSendRate);
			sendratesElement->QueryIntAttribute("incar", (int *)&iNetModeNormalIncarSendRate);
			sendratesElement->QueryIntAttribute("firing", (int *)&iNetModeFiringSendRate);
			sendratesElement->QueryIntAttribute("multiplier", (int *)&iNetModeSendMultiplier);
		}

		// get normal mode pos
		TiXmlElement* normalPosElement = rakSAMPElement->FirstChildElement("normal_pos");
		if(normalPosElement)
		{
			normalPosElement->QueryVectorAttribute("position", (float *)&settings.fNormalModePos);
			normalPosElement->QueryFloatAttribute("rotation", &settings.fNormalModeRot);
			normalPosElement->QueryIntAttribute("force", (int *)&settings.iNormalModePosForce);
		}

		// get auto run commands
		TiXmlElement* autorunElement = rakSAMPElement->FirstChildElement("autorun");
		if(autorunElement)
		{
			for(int i = 0; i < MAX_AUTORUN_CMDS; i++)
			{
				if(autorunElement)
				{
					settings.autoRunCMDs[i].iExists = 1;
					strcpy(settings.autoRunCMDs[i].szCMD, autorunElement->GetText());
					autorunElement = autorunElement->NextSiblingElement("autorun");
				}
				else
					break;
			}
		}

		TiXmlElement* findElement = rakSAMPElement->FirstChildElement("find");
		if(findElement)
		{
			for(int i = 0; i < MAX_FIND_ITEMS; i++)
			{
				if(findElement)
				{
					settings.findItems[i].iExists = 1;
					strcpy(settings.findItems[i].szFind, findElement->Attribute("text"));
					strcpy(settings.findItems[i].szSay, findElement->Attribute("say"));
					findElement->QueryColorAttribute("bk_color",
						(unsigned char *)&settings.findItems[i].bBkRed,
						(unsigned char *)&settings.findItems[i].bBkGreen,
						(unsigned char *)&settings.findItems[i].bBkBlue);
					findElement->QueryColorAttribute("text_color",
						(unsigned char *)&settings.findItems[i].bTextRed,
						(unsigned char *)&settings.findItems[i].bTextGreen,
						(unsigned char *)&settings.findItems[i].bTextBlue);

					findElement = findElement->NextSiblingElement("find");
				}
				else
					break;
			}
		}

		// get teleport locations
		TiXmlElement* teleportElement = rakSAMPElement->FirstChildElement("teleport");
		if(teleportElement)
		{
			for(int i = 0; i < MAX_TELEPORT_ITEMS; i++)
			{
				if(teleportElement)
				{
					settings.TeleportLocations[i].bCreated = 1;

					strcpy(settings.TeleportLocations[i].szName, (char *)teleportElement->Attribute("name"));
					teleportElement->QueryVectorAttribute("position", (float *)&settings.TeleportLocations[i].fPosition);

					teleportElement = teleportElement->NextSiblingElement("teleport");
				}
				else
					break;
			}
		}
	}

	if(hasXml)
		xmlSettings.Clear();

	PCHAR szCmdLine = GetCommandLineA();
	CHAR szPort[20];

	while(*szCmdLine)
	{
		if(*szCmdLine == '-' || *szCmdLine == '/')
		{
			szCmdLine++;
			switch(*szCmdLine)
			{
				case 'h':
					szCmdLine++;
					SetStringFromCommandLine(szCmdLine, settings.server.szAddr);
					break;
				case 'p':
					szCmdLine++;
					SetStringFromCommandLine(szCmdLine, szPort); settings.server.iPort = atoi(szPort);
					break;
				case 'n':
					szCmdLine++;
					SetStringFromCommandLine(szCmdLine, settings.server.szNickname);
					break;
				case 'z':
					szCmdLine++;
					SetStringFromCommandLine(szCmdLine, settings.server.szPassword);
					break;
			}
		}
		szCmdLine++;
	}

	return 1;
}

int UnLoadSettings()
{
	memset(&settings, 0, sizeof(settings));

	return 1;
}

int ReloadSettings()
{
	if(UnLoadSettings() && LoadSettings())
	{
		Log("Settings reloaded");
		return 1;
	}

	Log("Failed to reload settings");

	return 0;
}
